/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashSet;

import org.apache.hadoop.io.Writable;

/**
 * 
 * @author epl451
 * 
 */
public class IndexRecordWritable implements Writable {

	// Save each index record from maps
	private HashSet<IndexMapRecordWritable> tokens = new HashSet<IndexMapRecordWritable>();

	/**
	 * Default constructor
	 */
	public IndexRecordWritable() {
	}

	/**
	 * The parameter is a HashSet constructed from index records from maps
	 * 
	 * @param indexMapRecordWritables
	 */
	public IndexRecordWritable(
			Iterable<IndexMapRecordWritable> indexMapRecordWritables) {
		/**
		 * PUT YOUR CODE HERE
		 */
	}

	/**
	 * Concat all the index map records
	 */
	@Override
	public String toString() {

		StringBuilder output = new StringBuilder();

		/**
		 * PUT YOUR CODE HERE
		 */
		
		return output.toString();

	}

	/**
	 * Serialize the fields
	 */
	@Override
	public void write(DataOutput out) throws IOException {
		/**
		 * PUT YOUR CODE HERE
		 */
	}

	/**
	 * Deserialize the fields
	 */
	@Override
	public void readFields(DataInput in) throws IOException {
		/**
		 * PUT YOUR CODE HERE
		 */

	}

}
