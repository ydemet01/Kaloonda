package com.csdeptucy.app;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.mahout.clustering.classify.WeightedVectorWritable;
import org.apache.mahout.clustering.kmeans.KMeansDriver;
import org.apache.mahout.clustering.kmeans.Kluster;
import org.apache.mahout.common.HadoopUtil;
import org.apache.mahout.common.distance.CosineDistanceMeasure;

public class SimpleKMeansClusteringReuters {

	public static void main(String args[]) throws Exception {

		Configuration conf = new Configuration();
		conf.set("fs.hdfs.impl", org.apache.hadoop.hdfs.DistributedFileSystem.class.getName() );
		conf.set("fs.file.impl", org.apache.hadoop.fs.LocalFileSystem.class.getName() );
		
		FileSystem fs = FileSystem.get(conf);

		Path output = new Path("output");
		HadoopUtil.delete(conf, output);

		KMeansDriver.run(conf,
			new Path("mahout-work/reuters-out-seqdir-sparse-kmeans/tfidf-vectors"),
			new Path("mahout-work/reuters-kmeans-clusters/part-randomSeed"),
			output, new CosineDistanceMeasure(), 0.1, 10, true,
			0.0, false);

		SequenceFile.Reader reader = new SequenceFile.Reader(fs, new Path(
				"output/" + Kluster.CLUSTERED_POINTS_DIR + "/part-m-00000"),
				conf);

		IntWritable key = new IntWritable();
		WeightedVectorWritable value = new WeightedVectorWritable();
		while (reader.next(key, value)) {
			System.out.println(value.toString() + " belongs to cluster " + key.toString());
		}
		reader.close();
	}

}
